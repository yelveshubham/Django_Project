from django import forms

class SubmitForm(forms.Form):
    name = forms.CharField(max_length=100)
    age = forms.IntegerField(min_value=1)
    salary = forms.FloatField(min_value=0)

class JokeForm(forms.Form):
    count = forms.IntegerField(min_value=1)
