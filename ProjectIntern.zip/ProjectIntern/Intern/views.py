from django.http import JsonResponse
from django.shortcuts import render
from django.http import HttpResponse
from .forms import SubmitForm, JokeForm
import requests

def greet_user(request):
    name = request.GET.get('name', '')
    if name:
        return JsonResponse({'message': f"Hello {name}"})
    else:
        return JsonResponse({'error': 'Name parameter is required'}, status=400)

def process_form(request):
    if request.method == 'POST':
        name = request.POST.get('name', '')
        age = request.POST.get('age', '')
        salary = request.POST.get('salary', '')

        if not name or not isinstance(name, str):
            return render(request, 'myapp/form.html', {'message': 'Invalid name'})
        try:
            age = int(age)
            if age <= 0:
                raise ValueError
        except ValueError:
            return render(request, 'myapp/form.html', {'message': 'Invalid age'})
        try:
            salary = float(salary)
            if salary <= 0:
                raise ValueError
        except ValueError:
            return render(request, 'myapp/form.html', {'message': 'Invalid salary'})

        return render(request, 'myapp/form.html', {'message': f"{name} is {age} years old and earns {salary} every month"})

    return render(request, 'myapp/form.html')




def get_jokes(request):
    if request.method == 'POST':
        count = request.POST.get('count', '1')
        try:
            count = int(count)
            if count <= 0:
                raise ValueError
        except ValueError:
            return render(request, 'myapp/joke_form.html', {'message': 'Invalid count'})

        api_url = f"https://api.api-ninjas.com/v1/jokes?limit={count}"
        headers = {'X-Api-Key': 'YOUR_API_KEY'}
        response = requests.get(api_url, headers=headers)

        if response.status_code == 200:
            jokes = [joke['joke'] for joke in response.json()]
            return render(request, 'myapp/joke_form.html', {'jokes': jokes})
        else:
            return render(request, 'myapp/joke_form.html', {'message': 'Failed to fetch jokes'})

    return render(request, 'myapp/joke_form.html')



def process_form(request):
    if request.method == 'POST':
        form = SubmitForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            age = form.cleaned_data['age']
            salary = form.cleaned_data['salary']
            return render(request, 'myapp/form.html', {'message': f"{name} is {age} years old and earns {salary} every month"})
        else:
            return render(request, 'myapp/form.html', {'form': form})

    return render(request, 'myapp/form.html', {'form': SubmitForm()})

def get_jokes(request):
    if request.method == 'POST':
        form = JokeForm(request.POST)
        if form.is_valid():
            count = form.cleaned_data['count']
            # Fetch jokes from external API
            api_url = f"https://api.api-ninjas.com/v1/jokes?limit={count}"
            headers = {'X-Api-Key': 'YOUR_API_KEY'}
            response = requests.get(api_url, headers=headers)

            if response.status_code == 200:
                jokes = [joke['joke'] for joke in response.json()]
                return render(request, 'myapp/joke_form.html', {'jokes': jokes, 'form': form})
            else:
                return render(request, 'myapp/joke_form.html', {'message': 'Failed to fetch jokes', 'form': form})

        return render(request, 'myapp/joke_form.html', {'form': form})

    return render(request, 'myapp/joke_form.html', {'form': JokeForm()})


